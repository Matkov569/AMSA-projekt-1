package com.example.myapplication

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel() {
    private val _x=MutableLiveData<Int>();
    val x:LiveData<Int>
        get()=_x

    init{
        _x.value = 1;
    }

    public fun update(){
        var temp = x?.value?:0;
        _x.value = temp+1;
    }

}